//var https=require('https')
 /*
Author:Sudeshna
CreationDate:3Feb2019
Purpose:Assert the statusCode and ID for POST Request
*/
 
 var req=require('C:/Users/G O D/node_modules/request')
 var assert=require('assert')
 
 //Set the headers
 var headers={
	 'Content-Type':'application/json'
 }
 
 //Configure the request
 var options={
	 url:'https://jsonplaceholder.typicode.com/posts',
	 method:'POST',
	 headers:headers,
	 body:
	 {
	"title" :"foo",
	"body":"bar",
	"userId":1
},json:true
 }
 req(options,function(error,response,body){
	console.log("body"+JSON.stringify(body))
	console.log("response"+response.statusCode)
	assert.equal(response.statusCode,"201")
	assert.equal(body.id,"101")
 })