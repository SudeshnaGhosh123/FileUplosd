var chai = require('chai').use(require('chai-as-promised'));
var expect = chai.expect;
var a,b;
var APISteps = function() {

  var APIPage = require("../pages/API_page.js");

  this.World = function MyWorld() {
    this.page = new APIPage();
  };

  this.Given('Configure The Get Request', function (callback) {
    
	this.page.getRequest();
	
    callback();
  });
  
  this.Then('the statusCode should equal $StateCode and the id should equal $id', function (StateCode,id,callback) {
    this.page.ValidateResponse(StateCode,id);
    callback();
  });


   this.Given('Configure The POST Request', function (callback) {
    this.page.postRequest();
    callback();
  });

  
};

module.exports = APISteps;