var assert=require('assert')
var req=require('C:/Users/G O D/node_modules/request')
var fs=require('fs');
var f='C:/Program Files/nodejs/results.json';
var code;
var id,headers,options;

var APIPage = function() {


  this.getRequest = function() {
	  //var code1;
	  headers={
	 'Content-Type':'application/json'
 }
 
 //Configure the request
  options={
	 url:'https://jsonplaceholder.typicode.com/posts/1',
	 method:'GET',
	 headers:headers,
	 json:true
 }
 
 
 
  };

  this.ValidateResponse = function(cod,ID) {
	 
	req(options,function(error,response,body){
	console.log("body"+JSON.stringify(body))
	console.log("response"+response.statusCode)
	code=response.statusCode
	id=body.id
	f.statuscode=response.statusCode
	f.ID=body.id
	results.statusCode=response.statusCode
	code1=response.statusCode
	assert.equal(response.statusCode,cod)
	assert.equal(body.id,ID)
	
	
 })
	
    
  };
  
  this.postRequest=function(){
	 //Set the headers
  headers={
	 'Content-Type':'application/json'
 }
 
 //Configure the request
 options={
	 url:'https://jsonplaceholder.typicode.com/posts',
	 method:'POST',
	 headers:headers,
	 body:
	 {
	"title" :"foo",
	"body":"bar",
	"userId":1
},json:true
 }
 
  }
  
  

  
};

module.exports = APIPage;
