/*
Author:Sudeshna
CreationDate:2Feb2019
Purpose:To read and edit the json and write to a new file
*/

const fs = require('fs');
var file1='C:/Program Files/nodejs/student.json'

fs.readFile('student.json', (err, data) => {  
    if (err) throw err;
	console.log(JSON.parse(data))
  /*var sample=JSON.stringify(JSON.parse(data)) 
  console.log("sample"+sample)*/
  
  var file=require(file1)
  console.log("file"+JSON.stringify(file))
  
  // Editing the value
  file.name="Wipro"
  
  //Writing the Edited Value to a new File
  fs.writeFile('C:/Assignements/sample1.json',JSON.stringify(file),(err)=>{
	  if(err){
		  console.log("err")
	  }else{
		  console.log("Done")
	  }
  })
}); 