 /*
Author:Sudeshna
CreationDate:3Feb2019
Purpose:Assert the statusCode and ID for GET Request
*/

var req=require('C:/Users/G O D/node_modules/request')
 var assert=require('assert')
 
 //Set the headers
 var headers={
	 'Content-Type':'application/json'
 }
 
 //Configure the request
 var options={
	 url:'https://jsonplaceholder.typicode.com/posts/1',
	 method:'GET',
	 headers:headers,
	 json:true
 }
 req(options,function(error,response,body){
	console.log("body"+JSON.stringify(body))
	console.log("response"+response.statusCode)
	assert.equal(response.statusCode,"200")
	assert.equal(body.id,"1")
 })