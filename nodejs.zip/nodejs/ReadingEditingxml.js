/*
Author:Sudeshna
CreationDate:2Feb2019
Purpose:To read and edit the Xmldata and write to a new file
*/



var fs=require('fs'),
path=require('path'),
//parseString = require('C:/Users/G O D/node_modules/xml2js').parseString;
xml2js=require('C:/Users/G O D/node_modules/xml2js')
var parser = new xml2js.Parser();
extractedData = "";

//parser=require('C:/Users/G O D/node_modules/xml2js').Parser()

//filename=path.join('C:/Assignements/MyXml.xml')
fs.readFile('MyXml.xml', 'utf-8', function (err, data){
    if(err)
		console.log("eer"+err);
      // console.log(JSON.stringify(data))
	parser.parseString(data, function(err, result){
        if(err) console.log("err"+err);
        // here we log the results of our xml string conversion
		//extractedData = result['root']['graph']['node']['name'];
        console.dir("result"+JSON.stringify(result)); 
       var json = result;
		json.root.graph[0].node[0].name = "WiproLtd";
		var builder = new xml2js.Builder();
        var xml = builder.buildObject(json);
        
        fs.writeFile('C:/Assignements/edited-test.xml', xml, function(err, data){
            if (err) console.log(err);
            
            console.log("successfully written our update xml to file");
        })
                  
    });
});